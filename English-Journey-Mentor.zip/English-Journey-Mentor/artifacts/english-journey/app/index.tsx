import { Feather } from '@expo/vector-icons';
import { Redirect, router } from 'expo-router';
import React, { useState } from 'react';
import { Alert, Image, Text, View } from 'react-native';
import { ActionButton, Banner, Card, Chip, Field, FormPage, Heading } from '@/components/ui';
import { LEVELS } from '@/constants/learning';
import { useLearning } from '@/context/LearningContext';
import { useColors } from '@/hooks/useColors';

const portrait = require('../assets/images/profile.png');
const studyChoices = [20, 45, 60, 90, 120, 150];
const goals = ['Daily conversation', 'Career', 'Study abroad', 'IELTS'];

export default function OnboardingScreen() {
  const { state, ready, saveProfile } = useLearning();
  const colors = useColors();
  const [name, setName] = useState('');
  const [reportedLevel, setReportedLevel] = useState(1);
  const [studyMinutes, setStudyMinutes] = useState(45);
  const [goal, setGoal] = useState(goals[0]);
  const [ieltsGoal, setIeltsGoal] = useState('6.5');

  if (!ready) return <View style={{ flex: 1, backgroundColor: colors.background }} />;
  if (state.profile) return <Redirect href="/(tabs)" />;

  const start = () => {
    const cleanName = name.trim();
    if (cleanName.length < 2) {
      Alert.alert('Add your name', 'Enter at least two characters so your learning plan feels personal.');
      return;
    }
    saveProfile({
      name: cleanName,
      level: 1,
      reportedLevel,
      studyMinutes,
      goal,
      ieltsGoal: goal === 'IELTS' ? ieltsGoal : '',
    });
    router.replace('/(tabs)');
  };

  return (
    <FormPage>
      <View style={{ alignItems: 'center', marginTop: 10, marginBottom: 16 }}>
        <Image
          source={portrait}
          accessibilityLabel="Learner profile portrait"
          style={{ width: 68, height: 68, borderRadius: 34, borderWidth: 3, borderColor: colors.primary }}
        />
        <Text style={{ color: colors.primary, fontSize: 11, fontWeight: '800', letterSpacing: 1.4, marginTop: 12 }}>ENGLISH JOURNEY</Text>
      </View>
      <Heading title="Your next chapter starts here" subtitle="A few details help us build a daily English plan for you." />
      <Card>
        <Field
          label="What should we call you?"
          value={name}
          onChangeText={setName}
          placeholder="Your name"
          autoCapitalize="words"
          maxLength={40}
          returnKeyType="next"
          testID="learner-name"
        />
        <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: '700', marginBottom: 8 }}>How much time can you study each day?</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 17 }}>
          {studyChoices.map((minutes) => (
            <Chip key={minutes} title={minutes === 150 ? '150+ min' : `${minutes} min`} selected={studyMinutes === minutes} onPress={() => setStudyMinutes(minutes)} />
          ))}
        </View>
        <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: '700', marginBottom: 8 }}>What is your main goal?</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 17 }}>
          {goals.map((option) => (
            <Chip key={option} title={option} selected={goal === option} onPress={() => setGoal(option)} />
          ))}
        </View>
        {goal === 'IELTS' ? (
          <>
            <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: '700', marginBottom: 8 }}>Your target IELTS band</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 16 }}>
              {['5.5', '6.0', '6.5', '7.0', '7.5', '8.0'].map((band) => (
                <Chip key={band} title={band} selected={ieltsGoal === band} onPress={() => setIeltsGoal(band)} />
              ))}
            </View>
          </>
        ) : null}
        <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: '700', marginBottom: 7 }}>What level sounds closest to you?</Text>
        <Text style={{ color: colors.mutedForeground, fontSize: 11, lineHeight: 16, marginBottom: 9 }}>Your placement starts at Level 1 until your first skill check confirms a higher level.</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {LEVELS.map((level, index) => (
            <Chip key={level} title={`L${index + 1} · ${level}`} selected={reportedLevel === index + 1} onPress={() => setReportedLevel(index + 1)} />
          ))}
        </View>
      </Card>
      <Banner
        icon="download"
        title="Your lessons work offline"
        body="Your profile, saved lessons, vocabulary and progress stay on this device."
        tone="green"
      />
      <ActionButton title="Start my journey" icon="arrow-right" onPress={start} style={{ marginTop: 4 }} testID="start-journey" />
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, marginTop: 13 }}>
        <Feather name="smartphone" size={13} color={colors.mutedForeground} />
        <Text style={{ color: colors.mutedForeground, fontSize: 11 }}>Made for Android · Learning data stays on your device</Text>
      </View>
    </FormPage>
  );
}