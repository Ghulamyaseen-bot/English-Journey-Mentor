import { Feather } from '@expo/vector-icons';
import { Redirect, router } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Text, View } from 'react-native';
import { ActionButton, Avatar, Banner, Card, Chip, Field, FormPage, Heading } from '@/components/ui';
import { LEVELS } from '@/constants/learning';
import { useLearning } from '@/context/LearningContext';
import { useColors } from '@/hooks/useColors';

const studyChoices = [20, 45, 60, 90, 120, 150];
const goals = ['Daily conversation', 'Career', 'Study abroad', 'IELTS'];
const bands = ['5.5', '6.0', '6.5', '7.0', '7.5', '8.0'];

export default function ProfileScreen() {
  const { state, ready, storageError, updateProfile, resetProgress } = useLearning();
  const colors = useColors();
  const [name, setName] = useState<string>('');
  const [studyMinutes, setStudyMinutes] = useState<number>(45);
  const [goal, setGoal] = useState<string>(goals[0]);
  const [ieltsGoal, setIeltsGoal] = useState<string>('6.5');
  const [saved, setSaved] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!state.profile) return;
    setName(state.profile.name);
    setStudyMinutes(state.profile.studyMinutes);
    setGoal(state.profile.goal);
    setIeltsGoal(state.profile.ieltsGoal || '6.5');
  }, [state.profile]);

  if (!ready) return <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background }}><ActivityIndicator color={colors.primary} /></View>;
  if (!state.profile) return <Redirect href="/" />;

  const save = () => {
    const cleanName = name.trim();
    if (cleanName.length < 2) {
      setError('Enter at least two characters for your name.');
      setSaved(false);
      return;
    }
    updateProfile({
      name: cleanName,
      studyMinutes,
      goal,
      ieltsGoal: goal === 'IELTS' ? ieltsGoal : '',
    });
    setError(null);
    setSaved(true);
  };

  const confirmReset = () => {
    Alert.alert(
      'Reset all learning data?',
      'This permanently clears your local profile, level, saved words, study history, interview and writing history from this device.',
      [
        { text: 'Keep my data', style: 'cancel' },
        {
          text: 'Reset everything',
          style: 'destructive',
          onPress: () => {
            resetProgress();
            router.replace('/');
          },
        },
      ],
    );
  };

  return (
    <FormPage>
      <Heading eyebrow="Your account" title="Profile & learning plan" subtitle="Update your daily target and learning goal." />
      <Card>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <Avatar size={58} />
          <View style={{ flex: 1 }}>
            <Text style={{ color: colors.foreground, fontSize: 17, fontWeight: '800' }}>{state.profile.name}</Text>
            <Text style={{ color: colors.primary, fontSize: 11, fontWeight: '700', marginTop: 3 }}>Level {state.profile.level} · {LEVELS[state.profile.level - 1]}</Text>
          </View>
          <Feather name="smartphone" size={18} color={colors.mutedForeground} />
        </View>
      </Card>
      <Field label="Name" value={name} onChangeText={(value) => { setName(value); setSaved(false); }} maxLength={40} placeholder="Your name" autoCapitalize="words" />
      <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: '700', marginBottom: 8 }}>Daily study target</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 18 }}>
        {studyChoices.map((minutes) => <Chip key={minutes} title={minutes === 150 ? '150+ min' : `${minutes} min`} selected={studyMinutes === minutes} onPress={() => { setStudyMinutes(minutes); setSaved(false); }} />)}
      </View>
      <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: '700', marginBottom: 8 }}>Main learning goal</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 16 }}>
        {goals.map((item) => <Chip key={item} title={item} selected={goal === item} onPress={() => { setGoal(item); setSaved(false); }} />)}
      </View>
      {goal === 'IELTS' ? (
        <>
          <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: '700', marginBottom: 8 }}>Target IELTS band</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 16 }}>
            {bands.map((band) => <Chip key={band} title={band} selected={ieltsGoal === band} onPress={() => { setIeltsGoal(band); setSaved(false); }} />)}
          </View>
        </>
      ) : null}
      <ActionButton title="Save learning plan" icon="save" onPress={save} />
      {saved ? <Banner icon="check-circle" tone="green" title="Profile updated" body="Your new study goal and daily target are saved on this device." /> : null}
      {error ? <Banner icon="alert-circle" tone="orange" title="Check your name" body={error} /> : null}
      {storageError ? <Banner icon="alert-triangle" tone="red" title="Could not save local progress" body="Device storage is unavailable. Check free space and restart the app before relying on this data." /> : null}

      <Heading eyebrow="Your learning" title="Progress and placement" />
      <Card>
        <View style={{ gap: 11 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Text style={{ color: colors.mutedForeground, fontSize: 12 }}>Self-reported starting point</Text>
            <Text style={{ color: colors.foreground, fontSize: 12, fontWeight: '700' }}>Level {state.profile.reportedLevel}</Text>
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Text style={{ color: colors.mutedForeground, fontSize: 12 }}>Current level</Text>
            <Text style={{ color: colors.primary, fontSize: 12, fontWeight: '800' }}>Level {state.profile.level}</Text>
          </View>
          <Text style={{ color: colors.mutedForeground, fontSize: 11, lineHeight: 17 }}>Your course starts at Level 1. The placement check moves your level up only when your skill scores support it.</Text>
        </View>
      </Card>
      <ActionButton title={state.assessmentHistory.length ? 'Take another skill check' : 'Take my first skill check'} icon="clipboard" variant="secondary" onPress={() => router.push('/assessment')} />
      <ActionButton title="Open learning progress" icon="bar-chart-2" variant="outline" onPress={() => router.navigate('/(tabs)/progress')} style={{ marginTop: 9 }} />
      <ActionButton title="Chat with the English coach" icon="message-circle" variant="outline" onPress={() => router.push('/coach')} style={{ marginTop: 9 }} />

      <Heading eyebrow="Privacy" title="On-device learning data" />
      <Banner icon="lock" tone="green" title="Your learning history stays on this device" body="Profile details, study time, lesson scores, word memory, interviews and writing history are stored locally. AI requests are sent only when you choose an AI activity." />
      <Card>
        <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: '800' }}>Reset learning data</Text>
        <Text style={{ color: colors.mutedForeground, fontSize: 11, lineHeight: 17, marginTop: 5 }}>This deletes your entire English Journey profile and progress from this device. It cannot be undone.</Text>
        <ActionButton title="Reset all data" icon="trash-2" variant="outline" onPress={confirmReset} style={{ marginTop: 12, borderColor: colors.destructive }} />
      </Card>
    </FormPage>
  );
}