import { Feather } from '@expo/vector-icons';
import { Redirect, router } from 'expo-router';
import React from 'react';
import { ActivityIndicator, Text, View } from 'react-native';
import { ActionButton, Banner, Card, Heading, Page, ProgressBar } from '@/components/ui';
import { average, currentStreak, getDailyTasks, getTodayKey, LEVELS, SKILLS } from '@/constants/learning';
import { learningColors } from '@/constants/colors';
import { useLearning } from '@/context/LearningContext';
import { useColors } from '@/hooks/useColors';

function formatDay(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

export default function ProgressScreen() {
  const { state, ready } = useLearning();
  const colors = useColors();
  if (!ready) return <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background }}><ActivityIndicator color={colors.primary} /></View>;
  if (!state.profile) return <Redirect href="/" />;

  const today = getTodayKey();
  const tasks = getDailyTasks(state.profile.studyMinutes);
  const completeToday = state.completedByDate[today]?.length ?? 0;
  const latestAssessment = state.assessmentHistory[0];
  const previousAssessment = state.assessmentHistory[1];
  const overall = latestAssessment?.overall ?? average(Object.values(state.scores));
  const scores = Object.values(state.scores).filter((value) => value > 0);
  const days = Array.from({ length: 28 }, (_, index) => {
    const date = new Date();
    date.setDate(date.getDate() - (27 - index));
    const key = formatDay(date);
    return { date, key, active: state.studyDays.includes(key), label: date.toLocaleDateString('en', { weekday: 'short' }) };
  });
  const lastSevenDays = days.slice(-7);
  const weekActivity = lastSevenDays.map((day) => ({
    ...day,
    total: state.completedByDate[day.key]?.length ?? 0,
  }));
  const maxBar = Math.max(1, ...weekActivity.map((day) => day.total));
  const learnedWords = Object.values(state.wordMemory).filter((word) => word.correct >= 2).length;
  const masteredWords = Object.values(state.wordMemory).filter((word) => word.correct > word.incorrect).length;
  const reviewCount = state.mistakeMemory.length;

  return (
    <Page>
      <Heading eyebrow="Your progress" title="Look how far you've come" subtitle="A clear view of your practice and the skills you're building." />
      <Card style={{ backgroundColor: colors.navy, borderColor: colors.navy }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <View style={{ flex: 1, paddingRight: 8 }}>
            <Text style={{ color: colors.primaryForeground, fontSize: 10, fontWeight: '800', letterSpacing: 0.8 }}>LEVEL {state.profile.level} OF 8</Text>
            <Text style={{ color: colors.primaryForeground, fontSize: 20, fontWeight: '800', marginTop: 5 }}>{LEVELS[state.profile.level - 1]}</Text>
            <Text style={{ color: colors.primaryForeground, opacity: 0.82, fontSize: 12, lineHeight: 18, marginTop: 5 }}>
              {latestAssessment ? `Last check-in: ${new Date(latestAssessment.date).toLocaleDateString()}` : 'Complete a six-skill check-in for a starting score.'}
            </Text>
          </View>
          <View style={{ alignItems: 'center', justifyContent: 'center', width: 60, height: 60, borderRadius: 20, backgroundColor: colors.primary }}>
            <Text style={{ color: colors.primaryForeground, fontSize: 23, fontWeight: '800' }}>{overall}</Text>
            <Text style={{ color: colors.primaryForeground, fontSize: 8, fontWeight: '700' }}>SCORE</Text>
          </View>
        </View>
        <View style={{ marginTop: 13, flexDirection: 'row', alignItems: 'center', gap: 7 }}>
          <Feather name="zap" size={16} color={colors.warning} />
          <Text style={{ color: colors.primaryForeground, fontSize: 12, fontWeight: '700' }}>{currentStreak(state.studyDays)} day learning streak</Text>
        </View>
      </Card>

      <View style={{ flexDirection: 'row', gap: 8 }}>
        {[
          { label: 'Study time', value: `${state.totalStudyMinutes}m`, icon: 'clock', color: colors.primary },
          { label: 'Words learned', value: `${learnedWords}`, icon: 'book', color: learningColors.vocabulary },
          { label: 'Reading pace', value: state.readingWordsPerMinute ? `${state.readingWordsPerMinute}` : '—', icon: 'activity', color: learningColors.reading },
        ].map((metric) => (
          <Card key={metric.label} style={{ flex: 1, alignItems: 'flex-start', padding: 12, marginBottom: 0 }}>
            <Feather name={metric.icon as React.ComponentProps<typeof Feather>['name']} size={18} color={metric.color} />
            <Text style={{ color: colors.foreground, fontSize: 18, fontWeight: '800', marginTop: 6 }}>{metric.value}</Text>
            <Text numberOfLines={1} style={{ color: colors.mutedForeground, fontSize: 9, marginTop: 2 }}>{metric.label}</Text>
          </Card>
        ))}
      </View>

      <Heading eyebrow="Last seven days" title="Your weekly rhythm" subtitle={`${completeToday} of ${tasks.length} daily activities completed today.`} />
      <Card>
        <View style={{ height: 104, flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-around', gap: 7 }}>
          {weekActivity.map((day) => (
            <View key={day.key} style={{ flex: 1, height: '100%', alignItems: 'center', justifyContent: 'flex-end', gap: 5 }}>
              <Text style={{ color: colors.mutedForeground, fontSize: 9 }}>{day.total ? `${day.total}` : ''}</Text>
              <View style={{ width: '72%', height: Math.max(6, (day.total / maxBar) * 63), minHeight: 6, borderRadius: 7, backgroundColor: day.active ? colors.primary : colors.muted }} />
              <Text style={{ color: colors.mutedForeground, fontSize: 9 }}>{day.label.slice(0, 1)}</Text>
            </View>
          ))}
        </View>
        <View style={{ borderTopWidth: 1, borderTopColor: colors.border, marginTop: 12, paddingTop: 12 }}>
          <Text style={{ color: colors.foreground, fontSize: 12, fontWeight: '700' }}>28-day activity</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 9 }}>
            {days.map((day) => (
              <View key={day.key} accessibilityLabel={`${day.key}: ${day.active ? 'studied' : 'no study recorded'}`} style={{ width: 15, height: 15, borderRadius: 5, backgroundColor: day.active ? colors.teal : colors.muted }} />
            ))}
          </View>
        </View>
      </Card>

      <Heading eyebrow="Skills" title="Your current balance" subtitle={scores.length ? 'Recent lessons and placement checks update these scores.' : 'Scores appear after your first assessment or skill practice.'} />
      <Card>
        {SKILLS.map((skill) => {
          const current = state.scores[skill.id];
          const delta = latestAssessment && previousAssessment
            ? latestAssessment.scores[skill.id] - previousAssessment.scores[skill.id]
            : null;
          return (
            <View key={skill.id} style={{ marginBottom: 14 }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                <Text style={{ color: colors.foreground, fontSize: 12, fontWeight: '700' }}>{skill.label}</Text>
                <View style={{ flexDirection: 'row', gap: 6, alignItems: 'center' }}>
                  {delta !== null ? <Text style={{ color: delta >= 0 ? colors.success : colors.destructive, fontSize: 10, fontWeight: '700' }}>{delta >= 0 ? '+' : ''}{delta}</Text> : null}
                  <Text style={{ color: colors.mutedForeground, fontSize: 11 }}>{current > 0 ? `${current}%` : 'Not checked yet'}</Text>
                </View>
              </View>
              <ProgressBar value={current} color={learningColors[skill.id]} />
            </View>
          );
        })}
        {latestAssessment && previousAssessment ? (
          <Banner icon="trending-up" tone="green" title="Assessment comparison" body={`Overall ${latestAssessment.overall >= previousAssessment.overall ? 'improved' : 'changed'} from ${previousAssessment.overall}% to ${latestAssessment.overall}%.`} />
        ) : null}
      </Card>

      <Heading eyebrow="Learning habits" title="What you have built" />
      <Card>
        <View style={{ gap: 10 }}>
          {[
            ['calendar', 'Study days', `${state.studyDays.length} recorded`],
            ['book-open', 'Words seen', `${Object.values(state.wordMemory).reduce((sum, word) => sum + word.seen, 0)}`],
            ['check-circle', 'Words mastered', `${masteredWords}`],
            ['rotate-ccw', 'Saved mistakes', `${reviewCount}`],
          ].map(([icon, label, value]) => (
            <View key={label} style={{ flexDirection: 'row', alignItems: 'center', gap: 9 }}>
              <Feather name={icon as React.ComponentProps<typeof Feather>['name']} size={15} color={colors.primary} />
              <Text style={{ flex: 1, color: colors.foreground, fontSize: 12 }}>{label}</Text>
              <Text style={{ color: colors.mutedForeground, fontSize: 11, fontWeight: '700' }}>{value}</Text>
            </View>
          ))}
        </View>
      </Card>
      <ActionButton title={state.assessmentHistory.length ? 'Take another skill check' : 'Take your first skill check'} icon="clipboard" onPress={() => router.push('/assessment')} />
    </Page>
  );
}