import { Feather } from '@expo/vector-icons';
import { Redirect, router } from 'expo-router';
import React, { useState } from 'react';
import { Alert, Pressable, Text, View } from 'react-native';
import {
  ActionButton,
  Banner,
  Card,
  Field,
  FormPage,
  Heading,
  ProgressBar,
  SmallHeader,
} from '@/components/ui';
import { SpeakingRecorder } from '@/components/speaking';
import { useLearning, type SkillScores } from '@/context/LearningContext';
import { average, LEVELS, SKILLS } from '@/constants/learning';
import { getNetworkMessage, useLearningAI } from '@/hooks/useLearningAI';
import { useColors } from '@/hooks/useColors';

const steps = [
  { id: 'vocabulary', title: 'Vocabulary', prompt: 'Which word means “able to be trusted or depended on”?', options: ['reliable', 'curious', 'prepare', 'opportunity'], answer: 0 },
  { id: 'grammar', title: 'Grammar', prompt: 'Choose the correct sentence.', options: ['She study every day.', 'She studies every day.', 'She studying every day.', 'She are study every day.'], answer: 1 },
  { id: 'reading', title: 'Reading', passage: 'Nadia checks her bus time before leaving home. If it is raining, she walks to the covered stop ten minutes earlier. This small habit helps her arrive at work calmly.', prompt: 'Why does Nadia leave earlier when it rains?', options: ['To reach the covered stop calmly', 'To buy a new bus ticket', 'To meet a friend', 'To avoid checking the bus time'], answer: 0 },
] as const;

const allSkills: (keyof SkillScores)[] = ['vocabulary', 'grammar', 'reading', 'writing', 'speaking', 'interview'];

function AssessmentChoice({
  title,
  selected,
  correct,
  disabled,
  onPress,
}: {
  title: string;
  selected: boolean;
  correct?: boolean;
  disabled: boolean;
  onPress: () => void;
}) {
  const colors = useColors();
  const background = correct ? colors.successSoft : selected ? colors.accent : colors.card;
  const border = correct ? colors.success : selected ? colors.primary : colors.border;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected, disabled }}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => ({ minHeight: 47, justifyContent: 'center', paddingHorizontal: 13, paddingVertical: 10, borderRadius: 14, borderWidth: 1, borderColor: border, backgroundColor: background, opacity: pressed ? 0.75 : 1 })}
    >
      <Text style={{ color: colors.foreground, fontSize: 13, lineHeight: 19, fontWeight: selected || correct ? '700' : '500' }}>{title}</Text>
    </Pressable>
  );
}

export default function AssessmentScreen() {
  const { state, ready, finishAssessment } = useLearning();
  const colors = useColors();
  const { askCoach, busy } = useLearningAI();
  const [stepIndex, setStepIndex] = useState<number>(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [checked, setChecked] = useState<boolean>(false);
  const [draft, setDraft] = useState<string>('');
  const [feedback, setFeedback] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [scores, setScores] = useState<Partial<SkillScores>>({});
  const [finalResult, setFinalResult] = useState<{ level: number; promoted: boolean; score: number } | null>(null);

  if (!ready) return null;
  if (!state.profile) return <Redirect href="/" />;

  const level = state.profile.level;
  const stepCount = allSkills.length;
  const currentSkill = allSkills[stepIndex];
  const currentStep = steps[stepIndex];
  const skillTitle = SKILLS.find((skill) => skill.id === currentSkill)?.label ?? currentSkill;
  const currentScore = scores[currentSkill];

  const saveStepScore = (score: number, response?: string) => {
    setScores((previous) => ({ ...previous, [currentSkill]: score }));
    setFeedback(response ?? null);
    setChecked(true);
    setError(null);
  };

  const checkChoice = () => {
    if (!currentStep || selected === null) return;
    const correct = selected === currentStep.answer;
    if (!correct) setError(`A useful answer to remember: “${currentStep.options[currentStep.answer]}”.`);
    saveStepScore(correct ? 100 : 40);
  };

  const evaluateWriting = async () => {
    if (draft.trim().length < 12) {
      setError('Write at least a short sentence before submitting.');
      return;
    }
    setError(null);
    try {
      const result = await askCoach('assessment', draft.trim(), level, 'This is a placement assessment, not a lesson. Score the learner’s current written English fairly from 0 to 100. Give concise feedback and identify one next skill.');
      saveStepScore(result.score, result.feedback);
    } catch (cause) {
      setError(getNetworkMessage(cause));
    }
  };

  const evaluateInterview = async () => {
    if (draft.trim().length < 8) {
      setError('Write a little more so the coach can assess a complete answer.');
      return;
    }
    setError(null);
    try {
      const result = await askCoach('assessment', draft.trim(), level, 'This is a short placement interview. Score the learner’s current spoken-style English from 0 to 100 based on grammar, clarity and vocabulary. Do not score accent. Give concise feedback.');
      saveStepScore(result.score, result.feedback);
    } catch (cause) {
      setError(getNetworkMessage(cause));
    }
  };

  const finish = () => {
    const completedScores = allSkills.reduce((record, skill) => {
      record[skill] = scores[skill] ?? 0;
      return record;
    }, {} as SkillScores);
    if (Object.values(completedScores).some((score) => score === undefined)) return;
    const result = finishAssessment(completedScores);
    setFinalResult({ level: result.placedLevel, promoted: result.promoted, score: average(Object.values(completedScores)) });
  };

  const next = () => {
    if (stepIndex === stepCount - 1) {
      finish();
      return;
    }
    setStepIndex((previous) => previous + 1);
    setSelected(null);
    setChecked(false);
    setDraft('');
    setFeedback(null);
    setError(null);
  };

  const cancel = () => {
    Alert.alert('Leave the skill check?', 'Your current answers will not be used to change your level. You can return to lessons now and check in later.', [
      { text: 'Keep going', style: 'cancel' },
      { text: 'Leave check-in', style: 'destructive', onPress: () => router.replace('/(tabs)') },
    ]);
  };

  return (
    <FormPage>
      <SmallHeader title="Six-skill check-in" back={cancel} action={<View style={{ width: 38 }} />} />
      {finalResult ? (
        <Card style={{ alignItems: 'center', paddingVertical: 24 }}>
          <View style={{ width: 58, height: 58, borderRadius: 20, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.successSoft }}>
            <Feather name="award" size={28} color={colors.success} />
          </View>
          <Text style={{ color: colors.foreground, fontSize: 22, fontWeight: '800', marginTop: 12 }}>Check-in complete</Text>
          <Text style={{ color: colors.primary, fontSize: 18, fontWeight: '800', marginTop: 5 }}>Level {finalResult.level} · {LEVELS[finalResult.level - 1]}</Text>
          <Text style={{ color: colors.mutedForeground, fontSize: 13, marginTop: 7 }}>Overall skill score: {finalResult.score}%</Text>
          <Text style={{ color: colors.foreground, fontSize: 13, lineHeight: 20, textAlign: 'center', marginTop: 12 }}>
            {finalResult.promoted ? 'You met the score target across all six skills and moved up one level.' : state.assessmentHistory.length === 0 ? 'Your starting level is based on this check-in. You can review any skill from the Progress tab.' : 'Your level stays the same for now. Keep practising and check in again when you are ready.'}
          </Text>
          <ActionButton title="Go to my dashboard" icon="home" onPress={() => router.replace('/(tabs)')} style={{ width: '100%', marginTop: 18 }} />
        </Card>
      ) : (
        <>
          <Heading eyebrow={`CHECK-IN ${stepIndex + 1} OF ${stepCount}`} title={skillTitle} subtitle="Complete each short task to see your current skill balance." />
          <ProgressBar value={((stepIndex + (checked ? 1 : 0)) / stepCount) * 100} color={colors.primary} />
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 12, marginBottom: 12 }}>
            {allSkills.map((skill, index) => (
              <View key={skill} style={{ flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: index < stepIndex ? colors.successSoft : index === stepIndex ? colors.accent : colors.secondary, borderRadius: 10, paddingHorizontal: 8, paddingVertical: 6 }}>
                <Text style={{ color: index < stepIndex ? colors.success : index === stepIndex ? colors.primary : colors.mutedForeground, fontSize: 9, fontWeight: '700' }}>{index + 1} {skill.slice(0, 4)}</Text>
              </View>
            ))}
          </View>

          <Banner icon="info" title="A quick placement, not a pass/fail test" body="Your answers set a starting point. You can still use all saved lessons offline." />

          {currentStep ? (
            <Card>
              <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: '800', lineHeight: 23 }}>{currentStep.prompt}</Text>
              {'passage' in currentStep ? (
                <View style={{ backgroundColor: colors.secondary, borderRadius: 13, padding: 12, marginTop: 12, marginBottom: 12 }}>
                  <Text style={{ color: colors.foreground, fontSize: 12, lineHeight: 18 }}>{currentStep.passage}</Text>
                </View>
              ) : null}
              <View style={{ gap: 8, marginTop: 12 }}>
                {currentStep.options.map((option, index) => (
                  <AssessmentChoice
                    key={option}
                    title={option}
                    selected={selected === index}
                    correct={checked && index === currentStep.answer}
                    disabled={checked}
                    onPress={() => setSelected(index)}
                  />
                ))}
              </View>
              {checked ? (
                <Banner
                  icon={currentScore === 100 ? 'check' : 'book-open'}
                  tone={currentScore === 100 ? 'green' : 'orange'}
                  title={currentScore === 100 ? 'Good work' : 'We will use this as a learning signal'}
                  body={error ?? 'Your response has been saved for this check-in.'}
                />
              ) : null}
              {!checked ? <ActionButton title="Check answer" icon="check" onPress={checkChoice} disabled={selected === null} /> : null}
            </Card>
          ) : currentSkill === 'writing' ? (
            <Card>
              <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: '700', lineHeight: 22 }}>Write a few sentences about how you use English or how you would like to use it.</Text>
              <Field label="Writing sample" value={draft} onChangeText={setDraft} placeholder="Write in your own words…" multiline textAlignVertical="top" maxLength={1500} style={{ minHeight: 150, lineHeight: 20, marginTop: 12 }} testID="assessment-writing" />
              <ActionButton title={busy ? 'Reviewing…' : 'Assess my writing'} icon="zap" onPress={evaluateWriting} loading={busy} disabled={busy || checked} />
              {checked ? <Banner icon="check-circle" title={`Writing score: ${currentScore}%`} body={feedback ?? 'Your writing sample is saved for this check-in.'} tone="green" /> : null}
            </Card>
          ) : currentSkill === 'speaking' ? (
            <View>
              {checked ? (
                <Card>
                  <Banner icon="check-circle" tone="green" title={`Speaking score: ${currentScore}%`} body={feedback ?? 'Your recorded response has been assessed.'} />
                </Card>
              ) : (
                <SpeakingRecorder
                  trackProgress={false}
                  prompt="Introduce yourself and describe one thing you want to learn."
                  onEvaluated={(result) => saveStepScore(result.score, result.feedback)}
                />
              )}
            </View>
          ) : (
            <Card>
              <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: '700', lineHeight: 22 }}>Answer this interview question in English: What is one goal you are working toward?</Text>
              <Field label="Your answer" value={draft} onChangeText={setDraft} placeholder="Write a complete answer…" multiline textAlignVertical="top" maxLength={1500} style={{ minHeight: 120, lineHeight: 20, marginTop: 12 }} testID="assessment-interview" />
              <ActionButton title={busy ? 'Assessing…' : 'Assess my answer'} icon="message-circle" onPress={evaluateInterview} loading={busy} disabled={busy || checked} />
              {checked ? <Banner icon="check-circle" tone="green" title={`Interview score: ${currentScore}%`} body={feedback ?? 'Your answer has been assessed.'} /> : null}
            </Card>
          )}

          {error && !checked ? <Banner icon="wifi-off" title="Could not assess this answer" body={error} tone="orange" /> : null}
          {error && !checked && (currentSkill === 'writing' || currentSkill === 'interview') ? (
            <ActionButton title="Try assessment again" icon="refresh-cw" variant="outline" onPress={currentSkill === 'writing' ? evaluateWriting : evaluateInterview} disabled={busy} />
          ) : null}
          {checked ? <ActionButton title={stepIndex === stepCount - 1 ? 'See my placement' : 'Next skill'} icon="arrow-right" onPress={next} style={{ marginTop: 10 }} /> : null}
        </>
      )}
    </FormPage>
  );
}