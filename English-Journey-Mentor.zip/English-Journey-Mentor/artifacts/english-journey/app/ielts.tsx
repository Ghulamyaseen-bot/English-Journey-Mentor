import { Redirect, router } from 'expo-router';
import React from 'react';
import { useEffect } from 'react';
import { Alert } from 'react-native';
import { Heading, Page, SmallHeader } from '@/components/ui';
import { IELTSPractice } from '@/components/activities';
import { useLearning } from '@/context/LearningContext';

export default function IELTSRoute() {
  const { state, ready } = useLearning();
  const level = state.profile?.level ?? 1;

  useEffect(() => {
    if (ready && state.profile && level < 4) {
      Alert.alert('IELTS preparation is locked', 'Complete the Level 4 check-in to unlock IELTS-focused practice.', [
        { text: 'Back to learning', onPress: () => router.replace('/(tabs)/learn') },
      ]);
    }
  }, [ready, state.profile, level]);

  if (!ready) return null;
  if (!state.profile) return <Redirect href="/" />;
  if (level < 4) return <Page><Heading title="IELTS preparation is locked" subtitle="Complete the Level 4 check-in to unlock IELTS-focused practice." /></Page>;

  return (
    <Page>
      <SmallHeader title="IELTS preparation" back={() => router.back()} />
      <Heading eyebrow="Level 4 unlocked" title="Prepare for IELTS" subtitle="Academic reading, Task 2 writing and speaking prompts." />
      <IELTSPractice />
    </Page>
  );
}