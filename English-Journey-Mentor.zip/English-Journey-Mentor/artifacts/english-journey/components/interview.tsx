import { Feather } from '@expo/vector-icons';
import { Redirect } from 'expo-router';
import React, { useState } from 'react';
import { Text, View } from 'react-native';
import {
  ActionButton,
  Banner,
  Card,
  Field,
  FormPage,
  Heading,
  ProgressBar,
} from '@/components/ui';
import { FIRST_INTERVIEW_QUESTIONS, LEVELS } from '@/constants/learning';
import { useLearning } from '@/context/LearningContext';
import { getNetworkMessage, useLearningAI } from '@/hooks/useLearningAI';
import { useColors } from '@/hooks/useColors';

const interviewPrompts: Record<number, string[]> = {
  1: ['What is your name, and what do you enjoy doing?', 'Tell me about one thing you did today.', 'What would you like to learn this year?'],
  2: ['Can you tell me about your daily routine?', 'What do you usually do at the weekend?', 'Tell me about a person who helps you.'],
  3: ['What subject do you enjoy studying, and why?', 'Describe a place where you like to spend time.', 'What is one useful skill you have learned?'],
  4: ['Tell me about a goal you are working toward.', 'Describe a challenge that taught you something.', 'How do you organize your study time?'],
  5: ['What experience has taught you an important lesson?', 'Do you prefer to plan ahead or decide as you go?', 'What makes feedback useful to a learner?'],
  6: ['How is technology changing the way people learn?', 'What makes a good team leader?', 'How can cities become easier to live in?'],
  7: ['What makes a community a good place to live?', 'Should universities focus more on practical skills?', 'How can people make informed decisions online?'],
  8: ['How should professionals communicate when they disagree?', 'What responsibilities do companies have to their communities?', 'How can lifelong learning benefit society?'],
};

function nextUnusedPrompt(level: number, seen: string[]): string {
  const prompts = interviewPrompts[level] ?? interviewPrompts[1];
  const seenLower = new Set(seen.map((item) => item.trim().toLowerCase()));
  return prompts.find((prompt) => !seenLower.has(prompt.toLowerCase())) ?? 'Tell me about a new experience that changed your point of view.';
}

function parseNextQuestion(feedback: string, level: number, seen: string[]) {
  const labeled = feedback.match(/next question\s*:\s*([^\n]+)/i)?.[1]?.trim();
  const trailingQuestion = feedback.split('\n').map((line) => line.trim()).filter((line) => line.includes('?')).pop();
  const candidate = labeled ?? trailingQuestion;
  if (candidate && candidate.length > 8) return candidate;
  return nextUnusedPrompt(level, seen);
}

function stripNextQuestion(feedback: string) {
  return feedback.replace(/(?:^|\n)\s*Next question\s*:\s*[^\n]*/i, '').trim();
}

export default function InterviewScreen() {
  const { state, ready, completeActivity, rememberMistake, rememberInterviewQuestion, saveInterviewTurn } = useLearning();
  const colors = useColors();
  const { askCoach, busy } = useLearningAI();
  const level = state.profile?.level ?? 1;
  const [question, setQuestion] = useState<string>(() => nextUnusedPrompt(level, state.interviewQuestions));
  const [answer, setAnswer] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [focus, setFocus] = useState<string>('');
  const [score, setScore] = useState<number | null>(null);
  const [turnCount, setTurnCount] = useState<number>(0);
  const [sessionTurns, setSessionTurns] = useState<string[]>([]);
  const [summary, setSummary] = useState<string | null>(null);
  const [summaryScore, setSummaryScore] = useState<number | null>(null);

  if (!ready) return null;
  if (!state.profile) return <Redirect href="/" />;

  const submitAnswer = async () => {
    const cleanAnswer = answer.trim();
    if (cleanAnswer.length < 4) {
      setError('Add a little more detail so the coach can give useful feedback.');
      return;
    }
    setError(null);
    setFeedback(null);
    const history = state.interviewHistory.slice(0, 6).map((turn) => `Q: ${turn.question}\nA: ${turn.answer}`).join('\n');
    const context = `Interview question: ${question}\nPreviously asked questions: ${state.interviewQuestions.slice(-12).join(' | ')}\n${history}\nAfter short feedback and corrections, end the feedback with a separate line beginning exactly “Next question:” followed by exactly one new question.`;
    try {
      const result = await askCoach('interview', cleanAnswer, level, context.slice(0, 3900));
      const nextQuestion = parseNextQuestion(result.feedback, level, [...state.interviewQuestions, question]);
      const cleanFeedback = stripNextQuestion(result.feedback) || 'Thank you. Keep answering in complete sentences and add one specific detail.';
      setFeedback(cleanFeedback);
      setFocus(result.focus);
      setScore(result.score);
      setQuestion(nextQuestion);
      setAnswer('');
      setTurnCount((count) => count + 1);
      setSessionTurns((turns) => [...turns, `Question: ${question}\nAnswer: ${cleanAnswer}\nScore: ${result.score}/100`]);
      rememberInterviewQuestion(question);
      saveInterviewTurn(question, cleanAnswer, cleanFeedback, result.score);
      completeActivity('interview', 8, 'interview', result.score);
      result.corrections.forEach(rememberMistake);
    } catch (cause) {
      setError(getNetworkMessage(cause));
    }
  };

  const finishInterview = async () => {
    setError(null);
    try {
      const context = `The learner finished an English interview with ${turnCount} answers. Review these answers: ${sessionTurns.join('\n\n')}. Give a short overall interview summary, one strength, and one next practice target. Do not ask another question.`;
      const result = await askCoach('assessment', 'Please summarize my interview practice.', level, context.slice(0, 3900));
      setSummary(result.feedback);
      setSummaryScore(result.score);
      completeActivity('interview', 12, 'interview', result.score);
    } catch (cause) {
      setError(getNetworkMessage(cause));
    }
  };

  return (
    <FormPage>
      <Heading eyebrow="Adaptive English interview" title="One question at a time" subtitle={`Level ${level} · ${LEVELS[level - 1]} · Your previous questions are remembered.`} />
      <Banner icon="message-circle" title="Answer at your own pace" body="The coach responds to each answer with feedback, then asks one new question at your level." />
      {summary ? (
        <Card>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <Text style={{ color: colors.foreground, fontSize: 17, fontWeight: '800' }}>Interview summary</Text>
            <Text style={{ color: colors.primary, fontSize: 20, fontWeight: '800' }}>{summaryScore}%</Text>
          </View>
          <ProgressBar value={summaryScore ?? 0} color={colors.primary} />
          <Text style={{ color: colors.foreground, fontSize: 13, lineHeight: 20, marginTop: 12 }}>{summary}</Text>
          <ActionButton title="Start another interview" icon="rotate-ccw" variant="secondary" onPress={() => { setSummary(null); setSummaryScore(null); setTurnCount(0); setSessionTurns([]); setQuestion(nextUnusedPrompt(level, state.interviewQuestions)); setFeedback(null); setScore(null); }} style={{ marginTop: 14 }} />
        </Card>
      ) : (
        <>
          <Card>
            <Text style={{ color: colors.primary, fontSize: 10, fontWeight: '800', letterSpacing: 0.8 }}>QUESTION {turnCount + 1}</Text>
            <Text style={{ color: colors.foreground, fontSize: 19, fontWeight: '800', lineHeight: 27, marginTop: 7 }}>{question}</Text>
            {turnCount > 0 ? <Text style={{ color: colors.mutedForeground, fontSize: 11, lineHeight: 16, marginTop: 8 }}>Your last answer received {score}%.</Text> : null}
          </Card>
          <Field
            label="Your answer"
            value={answer}
            onChangeText={(text) => { setAnswer(text); setError(null); }}
            placeholder="Type your answer in English…"
            multiline
            textAlignVertical="top"
            maxLength={2400}
            style={{ minHeight: 135, lineHeight: 21 }}
            testID="interview-answer"
          />
          <ActionButton title={busy ? 'Reviewing your answer…' : 'Submit answer'} icon="arrow-right" onPress={submitAnswer} loading={busy} disabled={busy} />
          {turnCount > 0 ? (
            <ActionButton title="Finish and get a summary" icon="check-circle" variant="outline" onPress={finishInterview} disabled={busy} style={{ marginTop: 9 }} />
          ) : null}
          {error ? <Banner icon="wifi-off" title="Could not continue the interview" body={error} tone="orange" /> : null}
          {feedback ? (
            <Card style={{ marginTop: 13 }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: '800' }}>Coach feedback</Text>
                <Text style={{ color: colors.primary, fontSize: 19, fontWeight: '800' }}>{score}%</Text>
              </View>
              <ProgressBar value={score ?? 0} color={colors.primary} />
              <Text style={{ color: colors.foreground, fontSize: 13, lineHeight: 20, marginTop: 11 }}>{feedback}</Text>
              {focus ? <Banner icon="target" tone="green" title="Try next" body={focus} /> : null}
              <View style={{ flexDirection: 'row', gap: 7, alignItems: 'center', marginTop: 5 }}>
                <Feather name="arrow-down" size={14} color={colors.primary} />
                <Text style={{ color: colors.primary, fontSize: 11, fontWeight: '700' }}>Next question is ready above</Text>
              </View>
            </Card>
          ) : null}
        </>
      )}
      {state.interviewHistory.length > 0 ? (
        <Card style={{ marginTop: 12 }}>
          <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: '800' }}>Recent interview answers</Text>
          {state.interviewHistory.slice(0, 3).map((turn) => (
            <View key={turn.id} style={{ borderTopWidth: 1, borderTopColor: colors.border, marginTop: 10, paddingTop: 10 }}>
              <Text style={{ color: colors.mutedForeground, fontSize: 10 }}>SCORE {turn.score}% · {new Date(turn.date).toLocaleDateString()}</Text>
              <Text numberOfLines={2} style={{ color: colors.foreground, fontSize: 12, lineHeight: 17, marginTop: 4 }}>{turn.question}</Text>
              <Text numberOfLines={2} style={{ color: colors.mutedForeground, fontSize: 11, lineHeight: 16, marginTop: 3 }}>{turn.answer}</Text>
            </View>
          ))}
        </Card>
      ) : null}
    </FormPage>
  );
}