import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { LinearGradient } from 'expo-linear-gradient';
import React, { type ReactNode } from 'react';
import {
  ActivityIndicator,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  type TextInputProps,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import Svg, { Circle } from 'react-native-svg';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useColors } from '@/hooks/useColors';

const portrait = require('../assets/images/profile.png');

export function Avatar({ size = 48 }: { size?: number }) {
  const colors = useColors();
  return (
    <Image
      source={portrait}
      accessibilityLabel="Learner profile portrait"
      style={{ width: size, height: size, borderRadius: size / 2, borderWidth: 2, borderColor: colors.primary }}
    />
  );
}

export function Page({
  children,
  padded = true,
  background,
}: {
  children: ReactNode;
  padded?: boolean;
  background?: string;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  return (
    <SafeAreaView style={[styles.page, { backgroundColor: background ?? colors.background }]} edges={['top', 'left', 'right']}>
      <ScrollView
        keyboardShouldPersistTaps="handled"
        contentInsetAdjustmentBehavior="automatic"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          paddingHorizontal: padded ? 16 : 0,
          paddingTop: 4,
          paddingBottom: Math.max(insets.bottom, 18) + 84,
        }}
      >
        {children}
      </ScrollView>
    </SafeAreaView>
  );
}

export function FormPage({ children }: { children: ReactNode }) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  return (
    <SafeAreaView style={[styles.page, { backgroundColor: colors.background }]} edges={['top', 'left', 'right']}>
      <KeyboardAwareScrollViewCompat
        keyboardShouldPersistTaps="handled"
        bottomOffset={28}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          paddingHorizontal: 16,
          paddingTop: 8,
          paddingBottom: Math.max(insets.bottom, 20) + 24,
        }}
      >
        {children}
      </KeyboardAwareScrollViewCompat>
    </SafeAreaView>
  );
}

export function Field({
  label,
  helper,
  style,
  ...props
}: TextInputProps & { label: string; helper?: string }) {
  const colors = useColors();
  return (
    <View style={styles.fieldWrap}>
      <Text style={[styles.fieldLabel, { color: colors.foreground }]}>{label}</Text>
      <TextInput
        {...props}
        placeholderTextColor={colors.mutedForeground}
        selectionColor={colors.primary}
        style={[
          styles.field,
          { color: colors.foreground, borderColor: colors.input, backgroundColor: colors.card },
          style,
        ]}
      />
      {helper ? <Text style={[styles.fieldHelper, { color: colors.mutedForeground }]}>{helper}</Text> : null}
    </View>
  );
}

export function Heading({
  eyebrow,
  title,
  subtitle,
  right,
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  right?: ReactNode;
}) {
  const colors = useColors();
  return (
    <View style={styles.headingRow}>
      <View style={styles.headingText}>
        {eyebrow ? <Text style={[styles.eyebrow, { color: colors.primary }]}>{eyebrow}</Text> : null}
        <Text style={[styles.headingTitle, { color: colors.foreground }]}>{title}</Text>
        {subtitle ? <Text style={[styles.headingSubtitle, { color: colors.mutedForeground }]}>{subtitle}</Text> : null}
      </View>
      {right}
    </View>
  );
}

export function Card({
  children,
  style,
}: {
  children: ReactNode;
  style?: StyleProp<ViewStyle>;
}) {
  const colors = useColors();
  return (
    <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }, style]}>
      {children}
    </View>
  );
}

export function ActionButton({
  title,
  onPress,
  icon,
  variant = 'primary',
  disabled = false,
  loading = false,
  style,
  testID,
}: {
  title: string;
  onPress: () => void;
  icon?: React.ComponentProps<typeof Feather>['name'];
  variant?: 'primary' | 'secondary' | 'outline' | 'dark';
  disabled?: boolean;
  loading?: boolean;
  style?: StyleProp<ViewStyle>;
  testID?: string;
}) {
  const colors = useColors();
  const palette = {
    primary: { bg: colors.primary, fg: colors.primaryForeground, border: colors.primary },
    secondary: { bg: colors.secondary, fg: colors.secondaryForeground, border: colors.secondary },
    outline: { bg: 'transparent', fg: colors.primary, border: colors.border },
    dark: { bg: colors.navy, fg: colors.primaryForeground, border: colors.navy },
  }[variant];
  return (
    <Pressable
      testID={testID}
      accessibilityRole="button"
      disabled={disabled || loading}
      onPress={() => {
        if (disabled || loading) return;
        void Haptics.selectionAsync();
        onPress();
      }}
      style={({ pressed }) => [
        styles.actionButton,
        { backgroundColor: palette.bg, borderColor: palette.border, opacity: disabled ? 0.5 : pressed ? 0.82 : 1 },
        style,
      ]}
    >
      {loading ? <ActivityIndicator size="small" color={palette.fg} /> : null}
      {!loading && icon ? <Feather name={icon} size={17} color={palette.fg} /> : null}
      <Text style={[styles.actionText, { color: palette.fg }]}>{title}</Text>
    </Pressable>
  );
}

export function IconButton({
  icon,
  onPress,
  color,
  label,
  testID,
}: {
  icon: React.ComponentProps<typeof Feather>['name'];
  onPress: () => void;
  color?: string;
  label: string;
  testID?: string;
}) {
  const colors = useColors();
  return (
    <Pressable
      testID={testID}
      accessibilityRole="button"
      accessibilityLabel={label}
      onPress={onPress}
      hitSlop={10}
      style={({ pressed }) => [styles.iconButton, { opacity: pressed ? 0.65 : 1 }]}
    >
      <Feather name={icon} size={20} color={color ?? colors.foreground} />
    </Pressable>
  );
}

export function Chip({
  title,
  selected = false,
  onPress,
  style,
}: {
  title: string;
  selected?: boolean;
  onPress?: () => void;
  style?: StyleProp<ViewStyle>;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole={onPress ? 'button' : undefined}
      accessibilityState={{ selected }}
      onPress={onPress}
      style={[
        styles.chip,
        { backgroundColor: selected ? colors.primary : colors.secondary, borderColor: selected ? colors.primary : colors.border },
        style,
      ]}
    >
      <Text style={[styles.chipText, { color: selected ? colors.primaryForeground : colors.secondaryForeground }]}>{title}</Text>
    </Pressable>
  );
}

export function ProgressBar({ value, color }: { value: number; color?: string }) {
  const colors = useColors();
  const width = `${Math.min(100, Math.max(0, value))}%` as `${number}%`;
  return (
    <View style={[styles.progressTrack, { backgroundColor: colors.muted }]}>
      <View style={[styles.progressFill, { width, backgroundColor: color ?? colors.primary }]} />
    </View>
  );
}

export function ProgressRing({ value, size = 96 }: { value: number; size?: number }) {
  const colors = useColors();
  const stroke = 9;
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const dashOffset = circumference * (1 - Math.min(100, Math.max(0, value)) / 100);
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Svg width={size} height={size} style={{ position: 'absolute', transform: [{ rotate: '-90deg' }] }}>
        <Circle cx={size / 2} cy={size / 2} r={radius} stroke={colors.secondary} strokeWidth={stroke} fill="none" />
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={colors.teal}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={`${circumference} ${circumference}`}
          strokeDashoffset={dashOffset}
          fill="none"
        />
      </Svg>
      <Text style={{ fontSize: 20, fontWeight: '800', color: colors.foreground }}>{Math.round(value)}%</Text>
    </View>
  );
}

export function MetricCard({
  label,
  value,
  icon,
  color,
  onPress,
}: {
  label: string;
  value: string;
  icon: React.ComponentProps<typeof Feather>['name'];
  color?: string;
  onPress?: () => void;
}) {
  const colors = useColors();
  const content = (
    <View style={[styles.metricCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <Feather name={icon} size={19} color={color ?? colors.primary} />
      <Text style={[styles.metricValue, { color: colors.foreground }]}>{value}</Text>
      <Text numberOfLines={1} style={[styles.metricLabel, { color: colors.mutedForeground }]}>{label}</Text>
    </View>
  );
  return onPress ? (
    <Pressable onPress={onPress} accessibilityRole="button" accessibilityLabel={`${label}: ${value}`}>{content}</Pressable>
  ) : content;
}

export function LessonCard({
  title,
  subtitle,
  icon,
  color,
  onPress,
  locked = false,
}: {
  title: string;
  subtitle: string;
  icon: React.ComponentProps<typeof Feather>['name'];
  color: string;
  onPress: () => void;
  locked?: boolean;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={locked ? `${title}, locked` : title}
      onPress={onPress}
      style={({ pressed }) => [
        styles.lessonCard,
        { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.82 : 1 },
      ]}
    >
      <View style={[styles.lessonIcon, { backgroundColor: color }]}>
        <Feather name={locked ? 'lock' : icon} size={19} color={colors.primaryForeground} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={[styles.lessonTitle, { color: colors.foreground }]}>{title}</Text>
        <Text style={[styles.lessonSubtitle, { color: colors.mutedForeground }]}>{subtitle}</Text>
      </View>
      {!locked ? <Feather name="chevron-right" size={18} color={colors.mutedForeground} /> : null}
    </Pressable>
  );
}

export function SmallHeader({
  title,
  back,
  action,
}: {
  title: string;
  back?: () => void;
  action?: ReactNode;
}) {
  const colors = useColors();
  return (
    <View style={styles.smallHeader}>
      {back ? <IconButton icon="arrow-left" onPress={back} label="Back" /> : <View style={{ width: 38 }} />}
      <Text numberOfLines={1} style={[styles.smallHeaderTitle, { color: colors.foreground }]}>{title}</Text>
      {action ?? <View style={{ width: 38 }} />}
    </View>
  );
}

export function Banner({
  title,
  body,
  icon = 'info',
  tone = 'blue',
}: {
  title: string;
  body: string;
  icon?: React.ComponentProps<typeof Feather>['name'];
  tone?: 'blue' | 'green' | 'orange' | 'red';
}) {
  const colors = useColors();
  const bg = tone === 'green' ? colors.successSoft : tone === 'orange' ? colors.warningSoft : tone === 'red' ? colors.dangerSoft : colors.blueSoft;
  const fg = tone === 'green' ? colors.success : tone === 'orange' ? colors.warning : tone === 'red' ? colors.destructive : colors.primary;
  return (
    <View style={[styles.banner, { backgroundColor: bg }]}>
      <Feather name={icon} size={18} color={fg} />
      <View style={{ flex: 1 }}>
        <Text style={[styles.bannerTitle, { color: colors.foreground }]}>{title}</Text>
        <Text style={[styles.bannerBody, { color: colors.mutedForeground }]}>{body}</Text>
      </View>
    </View>
  );
}

export function HeaderGradient({ children }: { children: ReactNode }) {
  const colors = useColors();
  return (
    <LinearGradient
      colors={[colors.navy, colors.navyDeep, colors.primary]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={styles.headerGradient}
    >
      {children}
    </LinearGradient>
  );
}

export const sharedStyles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center' },
  spaceBetween: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  sectionGap: { height: 18 },
  inlineGap: { width: 10 },
});

const styles = StyleSheet.create({
  page: { flex: 1 },
  headerGradient: { borderBottomLeftRadius: 25, borderBottomRightRadius: 25, overflow: 'hidden' },
  fieldWrap: { gap: 7, marginBottom: 15 },
  fieldLabel: { fontSize: 13, fontWeight: '700' },
  field: { minHeight: 48, borderWidth: 1, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 11, fontSize: 14 },
  fieldHelper: { fontSize: 11, lineHeight: 16 },
  headingRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 12, marginBottom: 14 },
  headingText: { flex: 1, gap: 3 },
  eyebrow: { fontSize: 11, fontWeight: '700', letterSpacing: 1.1, textTransform: 'uppercase' },
  headingTitle: { fontSize: 25, lineHeight: 31, fontWeight: '800', letterSpacing: -0.4 },
  headingSubtitle: { fontSize: 13, lineHeight: 19 },
  card: { borderRadius: 20, borderWidth: 1, padding: 16, marginBottom: 12 },
  actionButton: { minHeight: 47, paddingHorizontal: 17, borderRadius: 15, borderWidth: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9 },
  actionText: { fontSize: 14, fontWeight: '700' },
  iconButton: { width: 38, height: 38, alignItems: 'center', justifyContent: 'center' },
  chip: { minHeight: 38, paddingHorizontal: 13, borderWidth: 1, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  chipText: { fontSize: 12, fontWeight: '700' },
  progressTrack: { height: 8, borderRadius: 8, overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 8 },
  metricCard: { flex: 1, minWidth: '30%', borderRadius: 17, borderWidth: 1, padding: 12, gap: 6, alignItems: 'flex-start' },
  metricValue: { fontSize: 20, fontWeight: '800' },
  metricLabel: { fontSize: 10, lineHeight: 14, fontWeight: '600' },
  lessonCard: { minHeight: 72, borderWidth: 1, borderRadius: 17, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 12 },
  lessonIcon: { width: 43, height: 43, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  lessonTitle: { fontSize: 14, fontWeight: '700' },
  lessonSubtitle: { fontSize: 11, marginTop: 3 },
  smallHeader: { minHeight: 46, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 2, marginBottom: 8 },
  smallHeaderTitle: { flex: 1, textAlign: 'center', fontSize: 16, fontWeight: '700' },
  banner: { borderRadius: 15, padding: 13, flexDirection: 'row', gap: 10, alignItems: 'flex-start', marginBottom: 12 },
  bannerTitle: { fontSize: 13, fontWeight: '700', marginBottom: 3 },
  bannerBody: { fontSize: 12, lineHeight: 17 },
});
