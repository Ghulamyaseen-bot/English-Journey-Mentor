/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

export const learningColors = {
  vocabulary: '#1976F3',
  reading: '#22B981',
  writing: '#7C67E8',
  speaking: '#F3A237',
  interview: '#ED5B70',
  grammar: '#16A6AF',
} as const;

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#102144',
    tint: '#1976F3',

    // Core surfaces
    background: '#F4F7FC',
    foreground: '#102144',

    // Cards / elevated surfaces
    card: '#FFFFFF',
    cardForeground: '#102144',

    // Primary action color (buttons, links, active states)
    primary: '#1976F3',
    primaryForeground: '#FFFFFF',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#EAF1FB',
    secondaryForeground: '#17325E',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#EAF0F7',
    mutedForeground: '#71809A',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#E5F1FF',
    accentForeground: '#1457AE',

    // Destructive actions (delete, error states)
    destructive: '#D94555',
    destructiveForeground: '#FFFFFF',

    // Borders and input outlines
    border: '#E1E8F1',
    input: '#D6DFEA',
    navy: '#102A5C',
    navyDeep: '#0B1D43',
    success: '#16A775',
    successSoft: '#E5F7F0',
    warning: '#E69B28',
    warningSoft: '#FFF3DE',
    dangerSoft: '#FFF0F1',
    blueSoft: '#EAF3FF',
    teal: '#12B9A1',
  },
  dark: {
    text: '#F1F5FC',
    tint: '#69A7FF',
    background: '#09162B',
    foreground: '#F1F5FC',
    card: '#132440',
    cardForeground: '#F1F5FC',
    primary: '#398AF7',
    primaryForeground: '#FFFFFF',
    secondary: '#1B3151',
    secondaryForeground: '#D8E6FC',
    muted: '#1A2B45',
    mutedForeground: '#9BABBF',
    accent: '#183A68',
    accentForeground: '#C6DFFF',
    destructive: '#E26B78',
    destructiveForeground: '#FFFFFF',
    border: '#253953',
    input: '#314763',
    navy: '#102A5C',
    navyDeep: '#0B1D43',
    success: '#36C392',
    successSoft: '#143D36',
    warning: '#E9AB46',
    warningSoft: '#3F3220',
    dangerSoft: '#43272F',
    blueSoft: '#193457',
    teal: '#28CBB5',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 18,
};

export default colors;
