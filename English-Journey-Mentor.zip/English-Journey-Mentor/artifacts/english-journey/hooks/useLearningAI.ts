import {
  useCreateLearningCoach,
  useTranscribeLearningAudio,
  type CreateLearningCoachMutationVariables,
} from '@workspace/api-client-react';
import type { SkillKey } from '@/constants/learning';

export type CoachTask = 'chat' | 'writing' | 'speaking' | 'interview' | 'assessment' | 'grammar' | 'reading';

export function useLearningAI() {
  const coach = useCreateLearningCoach();
  const transcribe = useTranscribeLearningAudio();

  const askCoach = async (
    task: CoachTask,
    message: string,
    level: number,
    context?: string,
  ) => {
    const request: CreateLearningCoachMutationVariables['data'] = {
      task,
      message,
      level,
      context,
    };
    return coach.mutateAsync({ data: request });
  };

  const transcribeRecording = async (uri: string) => {
    const file = {
      uri,
      name: 'english-journey-speaking.m4a',
      type: 'audio/mp4',
    } as unknown as Blob;
    return transcribe.mutateAsync({ data: { audio: file } });
  };

  return {
    askCoach,
    transcribeRecording,
    busy: coach.isPending || transcribe.isPending,
  };
}

export function getNetworkMessage(error: unknown): string {
  if (error && typeof error === 'object' && 'status' in error) {
    const status = (error as { status?: unknown }).status;
    if (status === 429) return 'Please wait a moment before trying another AI activity.';
    if (status === 503) return 'The AI service is temporarily unavailable. Check your connection and try again.';
  }
  return 'AI features require an internet connection.';
}

export function skillForTask(task: string): SkillKey | undefined {
  if (task === 'writing' || task === 'speaking' || task === 'interview' || task === 'reading') return task;
  if (task === 'grammar') return 'grammar';
  if (task === 'chat') return undefined;
  return undefined;
}